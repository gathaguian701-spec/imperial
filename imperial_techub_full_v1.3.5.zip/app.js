
// app.js - main site logic using Firebase modular SDK v10
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, RecaptchaVerifier, signInWithPhoneNumber, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyBNnNfTHE6h-hnTW6LAixiAJ7X--HMTMA0",
  authDomain: "imperial-techub.firebaseapp.com",
  projectId: "imperial-techub",
  storageBucket: "imperial-techub.firebasestorage.app",
  messagingSenderId: "361070773876",
  appId: "1:361070773876:web:ce41754e58a058e827f321"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// helpers
const $ = id => document.getElementById(id);
const show = el => el && el.classList.remove('hidden');
const hide = el => el && el.classList.add('hidden');

// Intro handling: show authArea after intro animation
document.addEventListener('DOMContentLoaded', ()=>{
  const intro = $('intro');
  intro.addEventListener('animationend', ()=>{
    intro.style.display = 'none';
    show($('authArea'));
  });
  setTimeout(()=>{ if(intro.style.display !== 'none'){ intro.style.display='none'; show($('authArea')); } },5200);
});

// Tabs
$('tabEmail').addEventListener('click', ()=>{ show($('emailForm')); hide($('phoneForm')); $('tabEmail').classList.add('active'); $('tabPhone').classList.remove('active'); });
$('tabPhone').addEventListener('click', ()=>{ hide($('emailForm')); show($('phoneForm')); $('tabPhone').classList.add('active'); $('tabEmail').classList.remove('active'); });

// Open register modal
$('btnOpenRegister').addEventListener('click', ()=> show($('registerModal')));
$('btnCancelRegister').addEventListener('click', ()=> hide($('registerModal')));

// Email sign-in
$('btnSignIn').addEventListener('click', async ()=>{
  const email = $('signinEmail').value.trim();
  const pw = $('signinPassword').value;
  if(!email || !pw){ $('signinMsg').innerText = 'Enter email and password'; return; }
  $('signinMsg').innerText = 'Signing in...';
  try{
    await signInWithEmailAndPassword(auth, email, pw);
    $('signinMsg').innerText = '';
  }catch(err){ console.error(err); $('signinMsg').innerText = 'Sign-in failed: ' + err.message; }
});

// Registration
$('btnCreateAccount').addEventListener('click', async ()=>{
  const fullName = $('regFullName').value.trim();
  const username = $('regUsername').value.trim();
  const email = $('regEmailReg').value.trim();
  const phone = $('regPhone').value.trim();
  const church = $('regChurch').value.trim();
  const district = $('regDistrict').value.trim();
  const pw = $('regPassword').value;
  const pw2 = $('regPassword2').value;
  if(!fullName||!username||!email||!phone||!pw){ $('regMsg').innerText = 'Please fill required fields'; return; }
  if(pw !== pw2){ $('regMsg').innerText = 'Passwords do not match'; return; }
  $('regMsg').innerText = 'Creating account...';
  try{
    const userCred = await createUserWithEmailAndPassword(auth, email, pw);
    const uid = userCred.user.uid;
    let photoURL = '';
    const file = $('regPhoto').files[0];
    if(file){
      const sref = storageRef(storage, `profiles/${uid}/${file.name}`);
      await uploadBytes(sref, file);
      photoURL = await getDownloadURL(sref);
    }
    await setDoc(doc(db, 'users', uid), { fullName, username, email, phone, church, district, photoURL, createdAt: serverTimestamp(), lastSeen: serverTimestamp(), online: true });
    $('regMsg').innerText = 'Account created.';
    hide($('registerModal'));
  }catch(err){ console.error(err); $('regMsg').innerText = 'Registration error: ' + err.message; }
});

// Phone auth
let recaptchaVerifier;
window.setupRecaptcha = () => {
  if(recaptchaVerifier) return;
  recaptchaVerifier = new RecaptchaVerifier('recaptcha-container', { size: 'invisible' }, auth);
  recaptchaVerifier.render();
};
window.setupRecaptcha();

$('btnSendOtp').addEventListener('click', async ()=>{
  const phone = $('phoneNumber').value.trim();
  if(!phone){ $('phoneMsg').innerText = 'Enter phone number'; return; }
  $('phoneMsg').innerText = 'Sending OTP...';
  try{
    const confirmationResult = await signInWithPhoneNumber(auth, phone, recaptchaVerifier);
    window.confirmationResult = confirmationResult;
    $('phoneMsg').innerText = 'OTP sent. Enter code.';
    $('otpCode').classList.remove('hidden');
    $('btnVerifyOtp').classList.remove('hidden');
    $('btnVerifyOtp').addEventListener('click', async ()=>{
      const code = $('otpCode').value.trim();
      if(!code){ $('phoneMsg').innerText = 'Enter code'; return; }
      try{
        await window.confirmationResult.confirm(code);
        $('phoneMsg').innerText = 'Phone sign-in successful';
      }catch(err){ console.error(err); $('phoneMsg').innerText = 'Verification failed: ' + err.message; }
    }, { once: true });
  }catch(err){ console.error(err); $('phoneMsg').innerText = 'Failed to send OTP: ' + err.message; }
});

// Auth state listener
onAuthStateChanged(auth, async user => {
  if(user){
    hide($('authArea'));
    show($('topbar'));
    show($('app'));
    // load profile
    try{
      const snap = await getDoc(doc(db, 'users', user.uid));
      if(snap.exists()){
        const d = snap.data();
        $('welcomeText').innerText = `Hello ${d.fullName || d.username || user.phoneNumber || user.email}`;
      } else {
        $('welcomeText').innerText = `Hello ${user.email || user.phoneNumber}`;
      }
    }catch(e){ console.warn(e); }
  } else {
    show($('authArea'));
    hide($('topbar'));
    hide($('app'));
  }
});

// Hymns sample
const HYMNS = [
  { title: "Amazing Grace", lyrics: "Amazing grace! How sweet the sound\nThat saved a wretch like me." },
  { title: "To God Be the Glory", lyrics: "To God be the glory, great things He hath done." }
];
function renderHymns(){
  const list = $('hymnList'); list.innerHTML = '';
  HYMNS.forEach(h => {
    const el = document.createElement('div'); el.className='hymn'; el.style.marginTop='8px';
    el.innerHTML = `<div style="font-weight:800">${h.title}</div><div class="muted">${h.lyrics.split('\n')[0]}...</div>`;
    el.addEventListener('click', ()=> alert(h.title + "\n\n" + h.lyrics));
    list.appendChild(el);
  });
}
renderHymns();

// Bible sample - load sample Genesis.txt from /bible/Genesis.txt if present
const BOOKS = ["Genesis","Exodus","Leviticus","Numbers"];
async function initBible(){
  const sel = $('bookSelect');
  BOOKS.forEach(b => { const o = document.createElement('option'); o.value=b; o.textContent=b; sel.appendChild(o); });
  sel.addEventListener('change', async ()=> {
    await loadBook(sel.value);
    populateChapters(sel.value);
    $('chapterSelect').value = '1';
    renderChapter(sel.value, '1');
  });
  // try load Genesis
  try{ await loadBook('Genesis'); populateChapters('Genesis'); renderChapter('Genesis','1'); }catch(e){ console.warn('Bible sample not available'); }
}
async function loadBook(book){
  if(window.bibleCache && window.bibleCache[book]) return;
  try{
    const res = await fetch('bible/' + book + '.txt');
    if(!res.ok) throw new Error('missing');
    const txt = await res.text();
    window.bibleCache = window.bibleCache || {};
    window.bibleCache[book] = txt;
    window.bibleParsed = window.bibleParsed || {};
    window.bibleParsed[book] = parseBookToChapters(txt);
  }catch(e){ console.warn(e); window.bibleParsed = window.bibleParsed || {}; window.bibleParsed[book] = {}; }
}
function parseBookToChapters(txt){
  const lines = txt.replace(/\r\n/g,'\n').split('\n');
  const chapters = {};
  let chapter = 1;
  let verses = [];
  lines.forEach(line => {
    if(/^CHAPTER\s+\d+/i.test(line)){ if(verses.length){ chapters[String(chapter)] = splitVerses(verses.join('\n')); verses = []; chapter++; } return; }
    verses.push(line);
  });
  if(verses.length) chapters[String(chapter)] = splitVerses(verses.join('\n'));
  return chapters;
}
function splitVerses(txt){
  const parts = txt.split(/\n\s*\n/).filter(Boolean);
  return parts.map((p,i)=>({verse:String(i+1), text:p.trim()}));
}
function populateChapters(book){
  const chSel = $('chapterSelect'); chSel.innerHTML = '';
  const chs = Object.keys(window.bibleParsed[book] || {});
  if(chs.length===0){ chSel.innerHTML = '<option>1</option>'; return; }
  chs.forEach(c => { const o = document.createElement('option'); o.value=c; o.textContent='Chapter '+c; chSel.appendChild(o); });
  chSel.addEventListener('change', ()=> renderChapter(book, chSel.value));
}
function renderChapter(book, chapter){
  const verses = (window.bibleParsed[book] && window.bibleParsed[book][chapter]) || [];
  const cont = $('versesContainer'); cont.innerHTML = '';
  verses.forEach(v => {
    const d = document.createElement('div'); d.style.marginTop='8px';
    d.innerHTML = `<strong>${v.verse}.</strong> ${v.text}`;
    cont.appendChild(d);
  });
}
initBible();

// Events rendering
function renderEvents(){
  const events = [
    {id:'youth-rally', title:'Youth Rally — PCEA Chieni Church', start:'2025-11-16T09:00:00'},
    {id:'presbytery', title:'Presbytery Youth Convention', start:'2025-12-02T09:00:00'},
    {id:'christmas', title:'Christmas Day', start:'2025-12-25T00:00:00'},
    {id:'newyear', title:"New Year's Day", start:'2026-01-01T00:00:00'}
  ];
  const cont = $('eventsGrid'); cont.innerHTML = '';
  events.forEach(ev => {
    const el = document.createElement('div'); el.style.marginTop='8px';
    el.innerHTML = `<div style="font-weight:800">${ev.title}</div><div class="muted">${new Date(ev.start).toDateString()}</div><div id="cd-${ev.id}" style="font-family:monospace;color:var(--accent)"></div>`;
    cont.appendChild(el);
  });
  setInterval(()=> {
    const now = new Date();
    events.forEach(ev => {
      const el = $('cd-'+ev.id);
      if(!el) return;
      const diff = new Date(ev.start) - now;
      if(diff<=0){ el.innerText = 'Happening or Passed'; return; }
      const d = Math.floor(diff/(24*3600*1000));
      const h = Math.floor((diff%(24*3600*1000))/(3600*1000));
      const m = Math.floor((diff%(3600*1000))/(60000));
      const s = Math.floor((diff%60000)/1000);
      el.innerText = `${d}d ${h}h ${m}m ${s}s`;
    });
  }, 1000);
}
renderEvents();

// Leaders
function renderLeaders(){
  const leaders = [
    { office:"Zachary's Office", name:"Zachary Gikonyo", role:"Chairperson", phone:"+254742892647" },
    { office:"Dalson's Office", name:"Dalson Maina", role:"Vice Chairperson", phone:"+254714003648" },
    { office:"Ian's Office", name:"Ian Gathagu", role:"Secretary", phone:"+254718357417" },
    { office:"Lydia's Office", name:"Lydia Wamuyu", role:"Vice Secretary", phone:"+254110867929" },
    { office:"Winnie's Office", name:"Winnie Maundu", role:"Treasurer", phone:"+254713285534" }
  ];
  const container = $('leadersGrid'); container.innerHTML = '';
  leaders.forEach(ld => {
    const el = document.createElement('div'); el.style.marginTop='8px';
    el.innerHTML = `<div style="font-weight:800">${ld.office}</div><div class="muted">${ld.name} — ${ld.role}</div><div style="margin-top:6px"><a href="https://wa.me/${ld.phone.replace(/\D/g,'')}" target="_blank" style="background:#25D366;color:#012;padding:6px 8px;border-radius:8px;display:inline-block;margin-right:6px">WhatsApp</a><a href="tel:${ld.phone.replace(/\D/g,'')}" style="background:#ffd54f;color:#012;padding:6px 8px;border-radius:8px;display:inline-block">Call</a></div>`;
    container.appendChild(el);
  });
}
renderLeaders();
