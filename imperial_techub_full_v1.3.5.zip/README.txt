Imperial Techub v1.3.5 - Full working ZIP (prototype)

Contents:
- index.html : single-page application (intro -> auth -> app)
- style.css  : styles
- app.js     : JavaScript (Firebase modular SDK v10 usage)
- bible/Genesis.txt (sample)
- bible/Exodus.txt (sample)
- hymns.json (sample hymns)
- README.txt (this file)

Instructions:
1. Extract the ZIP and host files on GitHub Pages or static web server.
2. Ensure Firebase Console:
   - Authentication: enable Email/Password and Phone
   - Firestore: create database
   - Storage: enable
3. If using Phone auth, ensure your domain is authorized in Firebase and reCAPTCHA works.
4. Upload full Bible files into /bible/ directory for full Bible reader.
5. For chat/messaging features, app.js contains placeholders. You can expand with Firestore collections.

Note: This is a prototype. Before production, secure Firestore with appropriate security rules.
