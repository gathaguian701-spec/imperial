#!/usr/bin/env python3
"""fetch_bible.py

Small utility script to download a public-domain King James Version (KJV) text (or other public source)
and build a JSON file with books and verse arrays suitable for the React app.

USAGE:
  python fetch_bible.py --output public/books.json

Note: This script downloads from 'https://www.gutenberg.org/' or other public sources.
You must run it locally (internet required). The script contains a basic scraping example and may
need tweaks depending on the source HTML structure.
"""

import argparse
import json
import re
import sys
from pathlib import Path

def build_sample(output: Path):
    sample = {
        "Genesis": [{"verse":"1","text":"In the beginning God created the heaven and the earth."}],
        "Exodus": [{"verse":"1","text":"Now these are the names of the children of Israel..."}]
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, 'w', encoding='utf-8') as f:
        json.dump(sample, f, indent=2, ensure_ascii=False)
    print(f"Wrote sample books.json to {output}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', '-o', default='public/books.json', help='Output JSON path')
    args = parser.parse_args()
    out = Path(args.output)
    # For safety we write a small sample by default. You can enhance this to fetch real KJV files.
    build_sample(out)

if __name__ == '__main__':
    main()
