import React, { useEffect, useState } from 'react'
import { collection, addDoc, query, orderBy, onSnapshot, serverTimestamp } from 'firebase/firestore'
import { db, storage } from '../firebase/config'
import { ref as sRef, uploadBytes, getDownloadURL } from 'firebase/storage'

export default function Home({ user }){
  const [text, setText] = useState('')
  const [image, setImage] = useState(null)
  const [posts, setPosts] = useState([])

  useEffect(()=> {
    const q = query(collection(db,'posts'), orderBy('createdAt','desc'))
    const unsub = onSnapshot(q, snap => { const arr = []; snap.forEach(s => arr.push({ id:s.id, ...s.data() })); setPosts(arr) })
    return ()=> unsub()
  },[])

  const createPost = async ()=>{
    if(!text && !image) return alert('Write or attach image')
    let mediaURL = ''
    if(image){ const path = `posts/${user.uid}/${Date.now()}_${image.name}`; const ref = sRef(storage, path); await uploadBytes(ref, image); mediaURL = await getDownloadURL(ref) }
    await addDoc(collection(db,'posts'), { authorId:user.uid, text, mediaURL, createdAt: serverTimestamp() })
    setText(''); setImage(null)
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Home Feed</h2>
      <div className="post-card p-4 bg-white/5 rounded mb-4">
        <textarea className="w-full p-3 rounded mb-2 text-black" placeholder="Share something" value={text} onChange={e=>setText(e.target.value)} />
        <input type="file" onChange={e=>setImage(e.target.files[0])} />
        <div className="mt-2"><button onClick={createPost} className="bg-blue-500 px-4 py-2 rounded">Post</button></div>
      </div>

      <div className="space-y-4">
        {posts.map(p=>(
          <div key={p.id} className="p-4 bg-white/5 rounded">
            <div className="font-bold">{p.text}</div>
            {p.mediaURL && <img src={p.mediaURL} alt="post" className="mt-2 max-w-full rounded" />}
            <div className="text-sm text-gray-300 mt-2">{p.createdAt ? new Date(p.createdAt.seconds*1000).toLocaleString() : ''}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
