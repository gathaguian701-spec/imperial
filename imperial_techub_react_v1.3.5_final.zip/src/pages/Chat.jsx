
import React, { useEffect, useState, useRef } from 'react'
import { collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp, updateDoc, doc, setDoc, getDoc } from 'firebase/firestore'
import { db, storage, auth } from '../firebase/config'
import { ref as sRef, uploadBytes, getDownloadURL } from 'firebase/storage'

export default function Chat({ user }){
  const [convos, setConvos] = useState([])
  const [current, setCurrent] = useState(null)
  const [msgs, setMsgs] = useState([])
  const [text, setText] = useState('')
  const [typingUsers, setTypingUsers] = useState([])
  const fileRef = useRef()

  useEffect(()=> {
    if(!user) return;
    const q = query(collection(db,'conversations'), where('members','array-contains', user.uid), orderBy('lastUpdated','desc'))
    const unsub = onSnapshot(q, snap => {
      const arr = []; snap.forEach(s=>arr.push({ id:s.id, ...s.data() }))
      setConvos(arr)
    })
    return ()=> unsub()
  },[user])

  useEffect(()=> {
    if(!current) return;
    const q = query(collection(db,'conversations',current.id,'messages'), orderBy('ts'))
    const unsub = onSnapshot(q, snap => {
      const arr = []; snap.forEach(s=>arr.push({ id:s.id, ...s.data() })); setMsgs(arr)
      // mark messages as seen by current user
      snap.forEach(async ms => {
        const m = ms.data();
        if(!m.seenBy || !m.seenBy.includes(user.uid)){
          try{ await updateDoc(doc(db,'conversations',current.id,'messages',ms.id), { seenBy: Array.from(new Set([...(m.seenBy||[]), user.uid])) }) }catch(e){}
        }
      })
    })
    // subscribe typing indicators
    const tcol = collection(db,'conversations',current.id,'typing')
    const unsubTyping = onSnapshot(tcol, tsnap=>{
      const arr=[]; tsnap.forEach(t=>{ const d=t.data(); if(d.uid !== user.uid && !d.idle) arr.push(d.uid) })
      setTypingUsers(arr)
    })
    return ()=> { unsub(); unsubTyping(); }
  },[current, user])

  const createGroup = async ()=>{
    const title = prompt('Group name')
    if(!title) return
    const membersRaw = prompt('Enter member emails separated by comma (optional)')
    const memberEmails = membersRaw ? membersRaw.split(',').map(s=>s.trim()).filter(Boolean) : []
    const memberIds = []
    // try to resolve emails to user ids (best-effort)
    for(const em of memberEmails){
      // naive lookup - requires users collection with email field
      // this is best-effort; if not found skip
      const usersRef = collection(db,'users')
      const q = query(usersRef, where('email','==', em))
      const snap = await (await import('firebase/firestore')).getDocs(q).catch(()=>null)
      if(snap && snap.size>0) { memberIds.push(snap.docs[0].id) }
    }
    memberIds.push(user.uid)
    const cRef = await addDoc(collection(db,'conversations'), { title, members: memberIds, createdAt: serverTimestamp(), createdBy:user.uid, lastUpdated: serverTimestamp(), lastMessage:'' })
    setCurrent({ id:cRef.id, title, members: memberIds })
  }

  const send = async ()=> {
    if(!current) return alert('Select conversation')
    if(!text && !fileRef.current.files[0]) return;
    // handle file
    const file = fileRef.current.files[0]
    if(file){
      const path = `media/${current.id}/${Date.now()}_${file.name}`
      const ref = sRef(storage, path)
      await uploadBytes(ref, file)
      const url = await getDownloadURL(ref)
      await addDoc(collection(db,'conversations',current.id,'messages'), { sender:user.uid, text:'', mediaURL:url, type: file.type.startsWith('image')?'image':'file', ts: serverTimestamp(), seenBy:[] })
      await updateDoc(doc(db,'conversations',current.id), { lastMessage:'[media]', lastUpdated: serverTimestamp() }).catch(()=>{})
      fileRef.current.value = ''
    }
    if(text){
      await addDoc(collection(db,'conversations',current.id,'messages'), { sender:user.uid, text, type:'text', ts: serverTimestamp(), seenBy:[] })
      await updateDoc(doc(db,'conversations',current.id), { lastMessage:text, lastUpdated: serverTimestamp() }).catch(()=>{})
      setText('')
    }
  }

  // typing indicator write
  let typingTimeout = null
  const onType = async (v)=>{
    setText(v)
    if(!current) return
    const tref = doc(db,'conversations',current.id,'typing', user.uid)
    await setDoc(tref, { uid:user.uid, ts: serverTimestamp() })
    if(typingTimeout) clearTimeout(typingTimeout)
    typingTimeout = setTimeout(async ()=>{
      await setDoc(tref, { uid:user.uid, ts: serverTimestamp(), idle:true }).catch(()=>{})
    }, 1500)
  }

  return (
    <div className="max-w-6xl mx-auto p-6 grid grid-cols-3 gap-4">
      <div className="col-span-1">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-bold">Conversations</h3>
          <button className="bg-green-500 px-2 py-1 rounded text-black" onClick={createGroup}>New</button>
        </div>
        <div className="space-y-2 overflow-auto" style={{maxHeight: '70vh'}}>
          {convos.map(c=>(
            <div key={c.id} className="p-2 bg-white/5 rounded cursor-pointer" onClick={()=>setCurrent(c)}>
              <div className="font-bold">{c.title || 'Group'}</div>
              <div className="text-sm text-gray-300">{c.lastMessage}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="col-span-2">
        <div className="p-4 bg-white/5 rounded mb-2">
          <h3 className="font-bold">{current ? current.title : 'Select a conversation'}</h3>
          <div className="text-sm text-gray-300">{current ? `Members: ${current.members?.length||0}` : ''}</div>
        </div>
        <div className="p-4 bg-white/5 rounded h-96 overflow-auto">
          {msgs.map(m=> (
            <div key={m.id} className={m.sender===user.uid ? 'text-right' : 'text-left'}>
              <div className="inline-block p-2" style={{background: m.sender===user.uid ? 'linear-gradient(90deg,#00b4ff,#66d8ff)' : 'rgba(255,255,255,0.03)', borderRadius: 10}}>
                {m.mediaURL ? <a href={m.mediaURL} target="_blank" rel="noreferrer">[media]</a> : m.text}
                <div className="text-xs text-gray-300">{m.seenBy && m.seenBy.length ? (m.seenBy.includes(user.uid) ? '✓✓' : '✓') : ''}</div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-2 flex gap-2">
          <input className="flex-1 p-2 rounded text-black" value={text} onChange={e=>onType(e.target.value)} placeholder="Type a message" />
          <input type="file" ref={fileRef} />
          <button onClick={send} className="bg-green-500 px-4 py-2 rounded">Send</button>
        </div>
        <div className="mt-2 text-sm text-gray-300">{typingUsers.length ? `${typingUsers.length} typing...` : ''}</div>
      </div>
    </div>
  )
}
