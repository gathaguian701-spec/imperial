import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { auth } from '../firebase/config'
import { signOut } from 'firebase/auth'

export default function TopNav(){ 
  const navigate = useNavigate()
  const handleSignOut = async () => {
    await signOut(auth)
    navigate('/auth')
  }

  return (
    <header className="bg-black/20 backdrop-blur sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-md bg-gradient-to-br from-[#00b4ff] to-[#62d3ff] flex items-center justify-center font-bold text-black">IT</div>
          <div className="text-lg font-bold">IMPERIAL TECHUB</div>
        </div>
        <nav className="flex gap-2 items-center">
          <Link className="px-3 py-2 rounded hover:bg-white/5" to="/">Home</Link>
          <Link className="px-3 py-2 rounded hover:bg-white/5" to="/chat">Chat</Link>
          <Link className="px-3 py-2 rounded hover:bg-white/5" to="/bible">Bible</Link>
          <button onClick={handleSignOut} className="px-3 py-2 rounded bg-red-500 text-black">Sign out</button>
        </nav>
      </div>
    </header>
  )
}
