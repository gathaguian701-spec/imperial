import React, { useState } from 'react'
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup } from 'firebase/auth'
import { auth, db, storage } from '../firebase/config'
import { setDoc, doc, serverTimestamp } from 'firebase/firestore'
import { ref as sRef, uploadBytes, getDownloadURL } from 'firebase/storage'

export default function Auth(){
  const [email,setEmail]=useState('');
  const [pw,setPw]=useState('');
  const [msg,setMsg]=useState('')

  const login = async ()=> {
    try{ await signInWithEmailAndPassword(auth,email,pw) }catch(e){ setMsg(e.message) }
  }

  const google = async ()=> {
    try{ const provider = new GoogleAuthProvider(); await signInWithPopup(auth, provider) }catch(e){ setMsg(e.message) }
  }

  const createAccount = async ()=> {
    try{ const cred = await createUserWithEmailAndPassword(auth,email,pw); await setDoc(doc(db,'users',cred.user.uid), { email, createdAt: serverTimestamp() }) }catch(e){ setMsg(e.message) }
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Sign in / Register</h2>
      <input className="w-full p-3 rounded mb-2 text-black" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input className="w-full p-3 rounded mb-2 text-black" placeholder="Password" type="password" value={pw} onChange={e=>setPw(e.target.value)} />
      <div className="flex gap-2">
        <button onClick={login} className="bg-blue-500 px-4 py-2 rounded">Sign in</button>
        <button onClick={google} className="bg-white text-black px-4 py-2 rounded">Google</button>
        <button onClick={createAccount} className="bg-green-500 px-4 py-2 rounded">Create</button>
      </div>
      <div className="mt-2 text-red-400">{msg}</div>
    </div>
  )
}
