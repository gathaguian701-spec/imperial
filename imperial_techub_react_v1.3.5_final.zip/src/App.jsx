import React, { useEffect, useState } from 'react'
import { Routes, Route, useNavigate } from 'react-router-dom'
import Home from './pages/Home'
import Chat from './pages/Chat'
import Bible from './pages/Bible'
import AuthPage from './pages/AuthPage'
import { auth } from './firebase/config'
import { onAuthStateChanged } from 'firebase/auth'
import TopNav from './components/TopNav'

export default function App(){
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(()=> {
    const unsub = onAuthStateChanged(auth, u => {
      setUser(u)
      setLoading(false)
      if(u) navigate('/')
      else navigate('/auth')
    })
    return ()=> unsub()
  },[])

  return (
    <div className="min-h-screen">
      {user && <TopNav user={user} />}
      <Routes>
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/" element={<Home user={user} />} />
        <Route path="/chat" element={<Chat user={user} />} />
        <Route path="/bible" element={<Bible user={user} />} />
      </Routes>
    </div>
  )
}
