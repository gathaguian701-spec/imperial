// Firebase config (user-provided)
import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'
import { getStorage } from 'firebase/storage'

const firebaseConfig = {
  apiKey: "AIzaSyBNnNfTHE6h-hnTW6LAixiAJ7X--HMTMA0",
  authDomain: "imperial-techub.firebaseapp.com",
  projectId: "imperial-techub",
  storageBucket: "imperial-techub.firebasestorage.app",
  messagingSenderId: "361070773876",
  appId: "1:361070773876:web:ce41754e58a058e827f321"
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getFirestore(app)
export const storage = getStorage(app)
