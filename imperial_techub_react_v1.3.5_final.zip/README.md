Imperial Techub v1.3.5 - React + Tailwind + Firebase starter

How to run:
1. Extract this folder.
2. npm install
3. npm run dev
4. Open http://localhost:5173

Notes:
- Firebase config is in src/firebase/config.js (already prefilled with your config).
- Enable Email/Password and Google Sign-In in Firebase Console. Add your domain to Authorized Domains.
- Upload bible/books.json to public/ to enable Bible reader.
- This is a starter scaffold. Chat and other features are minimally implemented and need production hardening.


Additional features added:
- Chat: typing indicator, seen receipts, create group UI (frontend)
- Firestore security rules at firestore.rules (example)
- GitHub Actions workflow for deploy to GitHub Pages (.github/workflows/deploy.yml)
- Bible sample at public/bible_books_sample.json (replace with full books.json for full Bible)

Next steps I can do:
- Generate a full books.json for the entire Bible (large file) and add to public/
- Harden Firestore rules and provide staging scripts
- Polish UI visuals per your exact branding
- Create a GitHub repository and push the code (I can provide exact git commands)


FINAL ACTIONS ADDED
- firestore.rules (stricter) included.
- fetch_bible.py: script to build public/books.json (run locally).
- Vitest + ESLint added (devDeps updated in package.json). Run `npm run test` and `npm run lint` after installing.
- TopNav updated with Sign out button.
- Tailwind theme tweaked.

HOW TO DEPLOY
1. npm install
2. npm run dev   # local dev
3. npm run build
4. Push to GitHub:
   git init
   git add .
   git commit -m "Initial React + Tailwind + Firebase"
   git branch -M main
   git remote add origin <your-git-repo-url>
   git push -u origin main

5. Enable GitHub Pages via the workflow in .github/workflows/deploy.yml OR deploy to Netlify/Vercel.

HOW TO ADD FULL BIBLE
- Run: python fetch_bible.py --output public/books.json
- Replace public/books.json with the file produced.

SECURITY
- Deploy firestore.rules by using the Firebase CLI:
  firebase deploy --only firestore:rules

