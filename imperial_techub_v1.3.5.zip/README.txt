Imperial Techub v1.3.5 - ZIP bundle
This archive contains a single-file prototype (index.html) that:
- Shows a 5-second intro, then login page (email/password + phone OTP)
- Hides navigation until successful login
- Uses Firebase modular SDK (v10.12.0) for Auth, Firestore, Storage
- Uses the Firebase config embedded in the HTML (provided by user)
- After login, the app UI and nav are revealed

Instructions:
1. Download and extract this ZIP.
2. Upload index.html to your GitHub Pages repo root (replace existing).
3. Ensure Firebase console: Authentication (Email/Password enabled) and Phone enabled, Firestore and Storage enabled.
4. If using Phone auth, ensure the phone number works and reCAPTCHA can render.
5. Open the page in browser. If Firebase SDK fails to load, check network or update module versions.

Security:
This is a prototype. Before public launch, add Firestore security rules to restrict access.

Files:
- index.html
- README.txt
